from django.db import models
from tinymce.models import HTMLField
from autoslug import AutoSlugField

# Create your models here.

class Movie(models.Model):
    bolly_id=models.AutoField(primary_key=True ,null=False , default=None)
    Movies_tittle=models.CharField(max_length=250,default=None)
    Gener = models.CharField(max_length=100 ,default=None,null=True,blank=True)
    Imdb = models.CharField(max_length=100 ,default=None,null=True)
    Timing = models.CharField(max_length=100 ,default=None,null=True,blank=True)
    quilety = models.CharField(max_length=100 ,default=None,null=True,blank=True)
    Cast = models.CharField(max_length=300 ,default=None,null=True,blank=True)
    producr = models.CharField(max_length=300 ,default=None,null=True,blank=True)
    Year = models.CharField(max_length=100 ,default=None,null=True,blank=True)
    myurl=models.CharField(max_length=200 ,default=None ,null=True)
    server_1=models.CharField(max_length=200 ,default=None ,null=True)
    server_2=models.CharField(max_length=200 ,default=None ,null=True)
    Mov_Description = HTMLField(null=True, blank=False ,default=None)
    Category=models.CharField(default=None, null=True, primary_key=False,max_length=100)
    trailer=models.CharField(max_length=250,null=False,default=None)
    Movies_img=models.FileField(upload_to="mmedia/",max_length=250,null=True,default=None)
    movi_slug =AutoSlugField(populate_from='Movies_tittle',unique=True,null=True,default=None)
    def __str__(self):
        return f"{self.Movies_tittle}"

class User_messege(models.Model):
    name =models.CharField(max_length=20)
    email = models.EmailField(max_length=30)
    number = models.CharField(max_length=30)
    desc = models.CharField(max_length=130)
    addvice = models.CharField(max_length=130)
    
    def __str__(self):
        return self.name
    