from django.contrib import admin    
from django.urls import path ,include
from mymovies import views
from django.conf import settings

from django.conf.urls.static import static


urlpatterns = [
    path('', views.index,  name='index'),
    path('login',views.login, name = 'login'),
    path('singin',views.singin, name = 'singin'),
    path('privacy',views.privacy, name = 'privacy'),
    path('user',views.user, name = 'user'),
    path('search',views.search, name = 'search'),
    path('inquiry',views.inquiry, name = 'inquiry'),
    path('term',views.term, name = 'term'),
    path('about',views.about, name = 'about'),
    path('contact',views.contact, name = 'contact'),
    path('logout',views.logout, name = 'logout'),
    path('<int:id>',views.detailpage, name = 'detailpage'),
    path('hollywood',views.hollywood, name='Hollywood'),
    path('bollywood',views.bollywood, name='bollywood'),
]


if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)