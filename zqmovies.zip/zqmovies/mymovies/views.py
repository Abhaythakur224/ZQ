from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth import login as lap
from django.contrib.auth import logout as djnago_logouts
from django.contrib.auth.models import User
from django.contrib import messages
from django.shortcuts import get_object_or_404
from mymovies.models import Movie, User_messege
from django.contrib.auth.decorators import login_required       
import random
# Create your views herdae.


def privacy(request):
    return render(request, 'privacy.html')
def contact(request):
    return render(request, 'contact.html')
def user(request):
    return render(request, 'user.html')

def search(request):
        # yahi method hame databse se data get karke deta hai
    servicedata = Movie.objects.all()
    if request.method == "GET":
        st = request.GET.get("servicename")
        if st != None:
            servicedata = Movie.objects.filter(Movies_tittle__contains=st)
    data = {
        'st':st,
        'servicedata': servicedata,
    }
    return render(request, 'search.html', data)


def term(request):
    return render(request, 'term.html')


def index(request):
    bol = Movie.objects.filter(Category__contains='Bollywood')
    hol = Movie.objects.filter(Category__contains='hollywood')
    al = Movie.objects.all()
    alb = Movie.objects.all()[:5]
    data = {
        'al': al,
        'bol': bol,
        'hol': hol,
        'alb': alb
    }
    return render(request, 'index.html', data)


def login(request):
    if request.method == "POST":
        # Get the post parameters
        username = request.POST['username']
        email = request.POST['email']
        phone = request.POST['phone']
        password = request.POST['password']
        # check for errorneous input
        try:
            user = User.objects.filter(username=username)
            messages.warning(
                request, "username Already taken. Try with different username.")
            return redirect('login')
        except User.DoesNotExist:
            # Create the user
            myuser = User.objects.create_user(
                username=username, email=email, password=password)
            myuser.first_name = phone
            # myuser.last_name = l_name
            myuser.phone = phone

            myuser.save()
            messages.success(
                request, " Your Account has been successfully created " + username)

            return redirect('index', {'username': username})
    else:
        return render(request, 'login.html')


def base(request):
    Contact = User.objects.all()  # yahi method hame databse se data get karke deta hai
    message = 'Save complete'
    data = {
        'Contact': Contact,
    }

    return render(request, 'base.html', data)


def singin(request):

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = authenticate(username=username, password=password)
        if user is not None:
            lap(request, user)
            messages.success(request, "Welcome back! " + username)
            return redirect('/')
        else:
            messages.error(request, "Check your Crdentials!!")
            return redirect('login')

    return render(request, "login.html")


def logout(request):
    djnago_logouts(request)
    messages.success(request, 'you are logout successfully!')
    return redirect('/')


def about(request):
    return render(request, 'about.html')


def detailpage(request, id):
    movita = get_object_or_404(Movie, pk=id)
    al = Movie.objects.all()[:9]
    data = {
        'movita': movita,
        'al': al,
    }
    return render(request, 'detailpage.html', data)

@login_required(login_url='login')
def inquiry(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        number = request.POST.get('number')
        desc = request.POST.get('desc')
        addvice = request.POST.get('addvice')

        content = User_messege(name=name, email=email,number=number, desc=desc, addvice=addvice)
        content.save()
        print(content)
        messages.success(request, 'Thankyou ' + name +
                         '  for Contacting us, your quiry will recived we will reply in 1 hour')
        return redirect('/')
        # thank = True
    return render(request, 'about.html')


def bollywood(request):
    toto = Movie.objects.filter(Category__contains='Bollywood')
    data = {
        'fillter': toto,
    }
    return render(request, 'bollywood.html', data)


def hollywood(request):
    toto = Movie.objects.filter(Category__contains='hollywood')
    data = {
        'fillter': toto,
    }
    return render(request, 'hollywood.html', data)


def video(request):
    movita = get_object_or_404(Movie, pk=id)
    bol = Movie.objects.filter(Category__contains='Bollywood')
    hol = Movie.objects.filter(Category__contains='hollywood')

    data = {
        'movita': movita,
        'bol': bol,
        'hol': hol
    }
    return render(request, 'video.html', data)
